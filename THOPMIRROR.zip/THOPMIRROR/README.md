#  - Jekyll Theme

THOPDB

### Copyright

Copyright (C) 2019 Sal, https://www.thopdb.com

**thopdb for Jekyll** is designed and developed by [Sal](https://www.THOPDB.COM) and it is *free* under MIT license. 



### Contribute

1. [Fork the repo](https://github.com/THOPDB).
2. Clone a copy of your fork on your local
3. Create a branch off of master and give it a meaningful name (e.g. my-new-mediumish-feature).
4. Make necessary changes, commit, push and open a pull request on GitHub.

Thank you!
